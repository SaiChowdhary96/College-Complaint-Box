package com.example.barmagopi.complaint;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class WelAdmin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wel_admin);
    }

    public void complaint(View view) {
        Intent i=new Intent(WelAdmin.this,ComplaintList.class);
        startActivity(i);
    }

    public void Logout(View view) {
        Intent i2=new Intent(WelAdmin.this,MainActivity.class);
        startActivity(i2);
    }
}
