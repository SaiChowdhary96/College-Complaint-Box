package com.example.barmagopi.complaint;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AdminPage extends AppCompatActivity {
    EditText adminname,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_page);
        adminname=(EditText)findViewById(R.id.e1);
        pass=(EditText)findViewById(R.id.e2);
    }
    public void login(View view)
    {
        validate();
        if(validate())
        {
            String username=adminname.getText().toString();
            String password=pass.getText().toString();
            if(username.equals("admin")&& password.equals("1234"))
            {
                Intent i=new Intent(AdminPage.this,WelAdmin.class);
                startActivity(i);
            }
        }
        else
            {
            Toast.makeText(this, "you are not allowed to Access ", Toast.LENGTH_SHORT).show();

        }

    }
    public boolean validate()
    {
        Boolean result=false;
        String username=adminname.getText().toString();
        String password=pass.getText().toString();
        if(username.isEmpty() || password.isEmpty())
        {
            Toast.makeText(this, "Please Enter Details", Toast.LENGTH_SHORT).show();
        }
        else
        {
            result=true;
        }
        return  result;
    }

}
