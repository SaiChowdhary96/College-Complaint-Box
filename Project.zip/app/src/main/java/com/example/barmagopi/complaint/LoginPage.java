package com.example.barmagopi.complaint;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginPage extends AppCompatActivity {
    EditText email,password;
    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page1);
        email=(EditText)findViewById(R.id.e1);
        password=(EditText)findViewById(R.id.e2);
        firebaseAuth=FirebaseAuth.getInstance();
        progressDialog=new ProgressDialog(this);
        FirebaseUser user=firebaseAuth.getCurrentUser();
        /*if(user != null)
        {
            finish();
            Intent i=new Intent(LoginPage.this,UserPage.class);
            startActivity(i);
        }*/
    }

    public void Register(View view) {
        Intent i=new Intent(LoginPage.this,RegisterPage.class);
        startActivity(i);
    }
    public void signin(View view)
    {
        check();
        if(check()) {
            validate(email.getText().toString(), password.getText().toString());
        }

    }
    private void validate(String email,String password)
    {
        progressDialog.setMessage("Please Wait....");
        firebaseAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(this,new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    progressDialog.dismiss();
                    Toast.makeText(LoginPage.this, "Login Successfull", Toast.LENGTH_SHORT).show();
                    Intent i=new Intent(LoginPage.this,UserPage.class);
                    startActivity(i);
                    finish();

                }
                else
                {
                    Toast.makeText(LoginPage.this, "Invalid Username And Password", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
    private boolean check()
    {
        Boolean result=false;
        String username=email.getText().toString();
        String pass=password.getText().toString();
        if(username.isEmpty() || pass.isEmpty())
        {
            Toast.makeText(this, "Please Enter Details", Toast.LENGTH_SHORT).show();
        }
        else
        {
            result=true;
        }
        return  result;
    }
}
