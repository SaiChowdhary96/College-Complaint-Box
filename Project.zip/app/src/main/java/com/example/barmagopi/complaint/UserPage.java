package com.example.barmagopi.complaint;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class UserPage extends AppCompatActivity {
    EditText username,depart,complaint;
    FirebaseDatabase firebaseDatabase;
    private FirebaseAuth firebaseAuth;
    DatabaseReference ref;
    User user;
    static int i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_page);
        username=(EditText)findViewById(R.id.user);
        depart=(EditText)findViewById(R.id.dep);
        complaint=(EditText)findViewById(R.id.comDes);
        firebaseDatabase=FirebaseDatabase.getInstance();
        ref=firebaseDatabase.getReference("User");
        user=new User();
    }
    private void  getValues()
    {
        user.setUsername(username.getText().toString());
        user.setDepart(depart.getText().toString());
        user.setComplaint(complaint.getText().toString());
    }
    public void send(View view)
    {
        getValues();
        final String name=username.getText().toString();
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                ref.child(name).setValue(user);
                Toast.makeText(UserPage.this, "Complaint Placed.....", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    public void Logout(View view) {
        Intent i=new Intent(UserPage.this,MainActivity.class);
        startActivity(i);
    }
}
