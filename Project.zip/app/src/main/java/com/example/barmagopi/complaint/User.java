package com.example.barmagopi.complaint;

public class User {
    private String Username;
    private  String Depart;
    private String Complaint;
public User()
{
}
public User(String name1,String Dept1,String Complaint1){
    Username=name1;
    Depart=Dept1;
    Complaint=Complaint1;
}

    public String getUsername() {
        return Username;
    }
    public void setUsername(String username) {
        Username = username;
    }


    public String getDepart() {
        return Depart;
    }
    public void setDepart(String depart) {
        this.Depart = depart;
    }


    public String getComplaint() {
        return Complaint;
    }
    public void setComplaint(String complaint) {
        this.Complaint = complaint;
    }

}
