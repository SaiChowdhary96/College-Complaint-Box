package com.example.barmagopi.complaint;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterPage extends AppCompatActivity {
    EditText e1,e2,e3,e4;
    String Username,Email,password;
    private FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_page1);
        e1=(EditText)findViewById(R.id.name);
        e2=(EditText)findViewById(R.id.reg);
        e3=(EditText)findViewById(R.id.branch);
        e4=(EditText)findViewById(R.id.ph);
        firebaseAuth=FirebaseAuth.getInstance();

    }
    public void signup(View view)
    {
        validate();
        if(validate())
        {
            //update details
	    // String email_rex="/^([a-zA-Z0-9\-\_\.]{0,})\@([a-zA-Z0-9\-\_\.]{0,})\.([a-zA-z]){2,}$/"; 
            String Email=e2.getText().toString();
            String password =e4.getText().toString();
            firebaseAuth.createUserWithEmailAndPassword(Email,password).addOnCompleteListener(this,new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()) {
                        Toast.makeText(RegisterPage.this, "Registration successful", Toast.LENGTH_SHORT).show();
                        Intent i=new Intent(RegisterPage.this,LoginPage.class);
                        startActivity(i);
                    } 
                    else
                    {
                        Toast.makeText(RegisterPage.this, "Registration Faild", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
    private boolean validate()
    {
        Boolean result=false;
        String username=e1.getText().toString();
        String RegNo=e2.getText().toString();
        String Branch=e3.getText().toString();
        String Mobile_Number=e4.getText().toString();
        if(username.isEmpty() || RegNo.isEmpty()|| Branch.isEmpty()||Mobile_Number.isEmpty())
        {
            Toast.makeText(this, "Please Enter Details", Toast.LENGTH_SHORT).show();
        }
        else
        {
            result=true;
        }
        return  result;
    }
}
